# AI Coffee Web App

1. run `npm install`
2. run `npm run dev`
